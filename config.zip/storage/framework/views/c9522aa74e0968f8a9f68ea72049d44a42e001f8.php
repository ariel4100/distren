<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('productos.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('productos.update',$producto->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="md-form">
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo $producto->title; ?>">
                        <label for="title" class="">Titulo</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="md-form">
                        <input type="text" id="order" name="order" class="form-control" value="<?php echo $producto->order; ?>">
                        <label for="order" class="">Orden</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="subtitle" class="md-textarea form-control" name="text" rows="3"><?php echo $producto->text; ?></textarea>
                    </div>
                </div>
            </div>
            
            <select-component :categoria="<?php echo e(json_encode($categorias)); ?>" :subcategoria="<?php echo e(json_encode($subcategorias)); ?>" :producto="<?php echo e(json_encode($producto)); ?>"></select-component>
            <div class="row">





















            </div>


            <capacidad-component :selectedcapacidad="<?php echo e(json_encode($producto->capacity)); ?>" :cierres="<?php echo e(json_encode($cierres)); ?>" :terminaciones="<?php echo e(json_encode($terminaciones)); ?>" :selectedcierre="<?php echo e(json_encode($producto->closure)); ?>" :selectedterminacion="<?php echo e(json_encode($producto->termination)); ?>"></capacidad-component>
            <gallery-component :galeria="<?php echo e(json_encode($producto->image)); ?>"></gallery-component>
            <div class="row mt-5">
                
                
                
                
                
                
                <div class="col-md-6 d-flex align-items-center justify-content-center">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" <?php echo $producto->featured ? 'checked': null; ?> id="customSwitch1" name="featured">
                        <label class="custom-control-label" for="customSwitch1">Destacado</label>
                    </div>
                </div>
                <div class="col-md-6 d-flex align-items-center justify-content-center">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" <?php echo $producto->offer ? 'checked': null; ?> id="Oferta" name="offer">
                        <label class="custom-control-label" for="Oferta">Oferta</label>
                    </div>
                </div>
                <div class="col-md-12 my-4 text-right">
                    <button type="submit"  class="btn btn-success">Guardar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/products/edit.blade.php ENDPATH**/ ?>