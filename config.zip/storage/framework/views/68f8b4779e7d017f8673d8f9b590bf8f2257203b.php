<!DOCTYPE html>
<html>
<body>
<h2>DISTREN</h2>

    <h3>Pedido</h3>
    <p>Enviado desde la web</p>
    <br>
<h3>Datos Personales</h3>
<ul>
    <li><strong>Nombre:</strong> <?php echo e($datos["nombre"]); ?> <?php echo e($datos["apellido"]); ?></li>
    <?php if(!empty($datos["telefono"])): ?>
        <li><strong>Télefono:</strong> <?php echo e($datos["telefono"]); ?></li>
    <?php endif; ?>
    <li><strong>Domicilio:</strong> <?php echo e($datos["domicilio"]); ?></li>
    <li><strong>Provincia:</strong> <?php echo e($datos["provincia"]); ?></li>
    <li><strong>Localidad:</strong> <?php echo e($datos["localidad"]); ?></li>
    <li><strong>Email:</strong> <a href="mailto:<?php echo e($datos['email']); ?>"><?php echo e($datos['email']); ?></a></li>
</ul>
<br>
<h4>Productos:</h4>
<table style="width:100%">
    <thead>
    <th style="background: #dedede; text-align:left; padding: 5px;">Categoria</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Producto</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">ml/cm2</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Precio</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Cant. Envases / Potes</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Subtotal</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Terminación</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Precio</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Cierre</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Cant. Cierres</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Precio</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Subtotal</th>
    <th style="background: #dedede; text-align:left; padding: 5px;">Subtotal Productos</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['categoria']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['producto']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cc']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['precio']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cantidad']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cantidad']*$p['precio']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['terminacion']['title']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['terminacion']['price']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cierre']['title']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cantidad_cierre']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cierre']['price']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p['cantidad_cierre']*$p['cierre']['price']); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e(($p['cantidad']*$p['precio'])+($p['cantidad']*$p['terminacion']['price'])+($p['cantidad_cierre']*$p['cierre']['price'])); ?></td>
            
            
            
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/mail/compra.blade.php ENDPATH**/ ?>