<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a href="<?php echo e(route('cierres.create')); ?>" class="btn btn-primary rounded-pill"><i class="fas fa-plus-circle mx-1"></i>Añadir</a>
        <div class="row">
            <div class="col-md-12">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Imagen</th>
                        <th scope="col">Titulo</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="width: 100px;">
                                <?php if($item->image): ?>
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" style="height: 300px;" alt="smaple image">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('uploads/no-img.png')); ?>" alt="" class="img-fluid">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td>
                                <a class="btn btn-sm btn-warning" href="<?php echo e(route('cierres.edit',$item->id)); ?>"><i class="fas fa-pen"></i></a>
                                <form action="<?php echo e(route('cierres.destroy', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button onclick="return confirm('¿Realmente desea eliminar este registro?')" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td>No hay registros</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/closures/index.blade.php ENDPATH**/ ?>