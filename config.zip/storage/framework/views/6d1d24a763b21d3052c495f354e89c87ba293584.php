<?php $__env->startSection('style'); ?>
    <style>
    P{
        margin-bottom:1px;
    }
    table{
        border-bottom: 2px solid #8BBF40 ;
    }
    thead td{
        text-align: center;
    }
        b{
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        
        <div class="row">
            <div class="col-md-12">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Email</th>
                        <th scope="col">Pago</th>
                        <th scope="col">Envio</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Total</th>
                        <th scope="col">Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>#0<?php echo e($item->id); ?></td>
                            <td><?php echo e($item->name .' '. $item->surname); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->transaction->payment); ?></td>
                            <td><?php echo e($item->transaction->shipping); ?></td>
                            <td>
                                <?php if($item->transaction->status == 'pendiente'): ?>
                                    <span class="badge badge-warning"><?php echo e(strtoupper($item->transaction->status)); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-success"><?php echo e(strtoupper($item->transaction->status)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>$ <?php echo e(number_format($item->transaction->total*1.21,2,',','.')); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal_order_<?php echo e($key); ?>">
                                    <i class="far fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th>No hay registros</th>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade" id="modal_order_<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <form action="<?php echo e(route('order.store')); ?>" method="post">
                                <div class="modal-header">
                                    <h4 class="modal-title w-100" id="myModalLabel">Orden de Compra</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="row justify-content-between">
                                        <div class="col-md-6">
                                            <h5 class="mb-3">DATOS DEL CLIENTE:</h5>
                                            <p><b class="font-weight-bold">NOMBRE Y APELLIDO: </b> <?php echo e($item->name .' '. $item->surname); ?></p>
                                            <p><b class="font-weight-bold">CUIT: </b> <?php echo e($item->cuit); ?></p>
                                            <p><b class="font-weight-bold">DOMICILIO: </b> <?php echo e($item->address); ?></p>
                                            <p><b class="font-weight-bold">PROVINCIA: </b> <?php echo e($item->province); ?></p>
                                            <p><b class="font-weight-bold">LOCALIDAD: </b> <?php echo e($item->location); ?></p>
                                            <p><b class="font-weight-bold">TELEFONO: </b> <?php echo e($item->phone); ?></p>
                                            <p><b class="font-weight-bold">EMAIL: </b> <a href="mailto:<?php echo e($item->email); ?>" class=" "><?php echo e($item->email); ?></a></p>

                                        </div>
                                        <div class="col-md-6">
                                            <h5 class="mb-3">ESTADO:</h5>
                                            <input type="text" class="d-none" value="<?php echo e($item->transaction->id); ?>" name="transaction_id">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <select name="status" id="" class="custom-select">
                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($s); ?>" <?php echo e($item->transaction->status == $s ? 'selected' : null); ?>><?php echo e($s); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                            <p><b class="font-weight-bold">PEDIDO: </b> #0<?php echo e($item->id); ?></p>
                                            <p><b class="font-weight-bold">FECHA DE COMPRA: </b> <?php echo e($item->transaction->created_at); ?></p>
                                            <p><b class="font-weight-bold">FORMA DE ENVIO: </b> <?php echo e($item->transaction->shipping); ?></p>
                                            <p><b class="font-weight-bold">FORMA DE PAGO: </b> <?php echo e($item->transaction->payment); ?></p>
                                            <p><b class="font-weight-bold">TOTAL: </b>$<?php echo e(number_format($item->transaction->total*1.21,2,',','.')); ?></p>
                                        </div>
                                        <div class="col-md-12"  >
                                            <table class="table mt-5">
                                                <thead class="distren-fondo white-text">
                                                <tr>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Categoria</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Producto</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Cantidad</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Terminaciones</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Cierre</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Cantidad</th>
                                                    <th class="align-middle py-1 text-center" style="border-right: 1px solid white; line-height: 1">Subtotal</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $item->order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php if($pedido->price_offer): ?>
                                                        <td><?php echo e($pedido->name_category); ?></td>
                                                        <td style="width: 170px;">
                                                            <?php echo e($pedido->name_product); ?>

                                                            <p class="m-0"><b>Capacidad: </b><?php echo e($pedido->cc); ?></p>
                                                            <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_offer,2,',','.')); ?></p>
                                                        </td>
                                                        <td><?php echo e($pedido->quantity_cc); ?></td>
                                                        <td style="width: 170px;">
                                                            <?php echo e($pedido->name_termination); ?>

                                                            <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_termination,2,',','.')); ?></p>
                                                        </td>
                                                        <td style="width: 170px;">
                                                            <?php echo e($pedido->name_closure); ?>

                                                            <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_closure,2,',','.')); ?></p>
                                                        </td>
                                                        <td><?php echo e($pedido->quantity_closure); ?></td>

                                                            <td>$<?php echo e(number_format(($pedido->quantity_cc*$pedido->price_offer) + ($pedido->quantity_cc*$pedido->price_termination) + ($pedido->quantity_closure*$pedido->price_closure),2,',','.')); ?></td>
                                                        <?php else: ?>
                                                            <td><?php echo e($pedido->name_category); ?></td>
                                                            <td style="width: 170px;">
                                                                <?php echo e($pedido->name_product); ?>

                                                                <p class="m-0"><b>Capacidad: </b><?php echo e($pedido->cc); ?></p>
                                                                <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_cc,2,',','.')); ?></p>
                                                            </td>
                                                            <td><?php echo e($pedido->quantity_cc); ?></td>
                                                            <td style="width: 170px;">
                                                                <?php echo e($pedido->name_termination); ?>

                                                                <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_termination,2,',','.')); ?></p>
                                                            </td>
                                                            <td style="width: 170px;">
                                                                <?php echo e($pedido->name_closure); ?>

                                                                <p class="m-0"><b>Precio: </b>$<?php echo e(number_format($pedido->price_closure,2,',','.')); ?></p>
                                                            </td>
                                                            <td><?php echo e($pedido->quantity_closure); ?></td>
                                                            <td>$<?php echo e(number_format(($pedido->quantity_cc*$pedido->price_cc) + ($pedido->quantity_cc*$pedido->price_termination) + ($pedido->quantity_closure*$pedido->price_closure),2,',','.')); ?></td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-4 offset-md-8">
                                            <div class="d-flex justify-content-between">
                                                <h5 class="">Sub Total</h5>
                                                <h5 class="">$ <?php echo e(number_format($item->transaction->total,2,',', '.')); ?></h5>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <h5 class="">IVA (21%)</h5>
                                                <h5>$<?php echo e(number_format($item->transaction->total*0.21,2,',', '.')); ?></h5>
                                            </div>
                                            
                                                
                                                
                                            
                                            <div class="d-flex justify-content-between align-item-center mt-3">
                                                <h5 class="distren-color m-0">Total a pagar</h5>
                                                <h5 class="m-0 text-dark">$<?php echo e(number_format($item->transaction->total*1.21,2,',', '.')); ?></h5>
                                            </div>
                                            <hr class="distren-fondo">
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cerrar</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Guardar Cambios</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/orders/index.blade.php ENDPATH**/ ?>