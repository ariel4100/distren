
<div class="col-md-3" id="sidebar">
    <ul class="list-unstyled">

        <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item border-0 px-0">
                <a href="<?php echo e(route('categoria',$item->id)); ?>" data-target="#categoria_<?php echo e($key); ?>" data-toggle="collapse" aria-expanded="false" class="d-flex align-items-center p-2 border-bottom <?php echo e($item->id == $categoria->id ? 'distren-color' : null); ?>">
                    <span onclick="location.href='<?php echo e(route('categoria',$item->id)); ?>'"><?php echo $item->title; ?></span><i class="fas fa-chevron-right ml-auto"></i>
                </a>
                <ul class="list-unstyled collapse <?php echo e($item->id ==  $categoria->id ? 'show' : null); ?>" id="categoria_<?php echo e($key); ?>">
                    <?php $__empty_2 = true; $__currentLoopData = $item->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <li><a href="<?php echo e(route('producto',$data->id)); ?>" class="px-3 py-2  <?php if(isset($producto)): ?> <?php echo e($data->id == $producto->id ? 'distren-color': null); ?><?php endif; ?>"><?php echo e($data->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <li><a href="" class="p-2">No hay registros</a></li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li><a href="" class="p-2">No hay registros</a></li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/partials/botonera.blade.php ENDPATH**/ ?>