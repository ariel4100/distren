<?php $__env->startSection('style'); ?>
    <style>
        .nav-link{
            color: #737384;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <?php echo $__env->make('page.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            
            <?php echo $__env->make('page.partials.botonera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <familia-component :subcategoria="<?php echo e(json_encode($subcategorias)); ?>" :productos="<?php echo e(json_encode($categoria->product)); ?>"></familia-component>






























































        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/productos/categoria.blade.php ENDPATH**/ ?>