<?php $__env->startSection('content'); ?>

    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('contenido.index',['seccion' => $section, 'tipo' => $type])); ?>"><< Volver</a>

        <form class="row" method="POST" action="<?php echo e(route('contenido.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="section" value="<?php echo e($section); ?>">
            <input type="hidden" name="type" value="<?php echo e($type); ?>">
            <?php if($section == 'home'): ?>
                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="order" name="order" class="form-control" value="<?php echo isset($contenido) ? $contenido->order : null; ?>">
                        <label for="order" class="">Orden</label>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="md-form">
                        <p>Texto</p>
                        <textarea id="text" class="md-textarea form-control" name="text" rows="3"></textarea>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($type == 'imagen'): ?>
            <div class="col-md-12">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                    <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                </div>
            </div>
            <?php else: ?>
                <div class="col-md-12">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="ficha" lang="es">
                        <label class="custom-file-label" for="customFileLang">Archivo Adjunto</label>
                    </div>
                </div>
            <?php endif; ?>
                <div class="col-md-12 my-4 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('text');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/content/create.blade.php ENDPATH**/ ?>