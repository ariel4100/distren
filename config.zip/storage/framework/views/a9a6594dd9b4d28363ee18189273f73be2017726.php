<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('productos.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('productos.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="md-form">
                            <input type="text" id="title" name="title" class="form-control">
                            <label for="title" class="">Titulo</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="md-form">
                            <input type="text" id="order" name="order" class="form-control">
                            <label for="order" class="">Orden</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form">
                            <h6>Texto</h6>
                            <textarea id="subtitle" class="md-textarea form-control" name="text" rows="3"></textarea>
                        </div>
                    </div>
                </div>

            <select-component :categoria="<?php echo e(json_encode($categorias)); ?>" :subcategoria="<?php echo e(json_encode($subcategorias)); ?>"></select-component>






















            <capacidad-component :terminaciones="<?php echo e(json_encode($terminaciones)); ?>" :capacidades="<?php echo e(json_encode($capacidades)); ?>" :cierres="<?php echo e(json_encode($cierres)); ?>"></capacidad-component>
            <gallery-component></gallery-component>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="customSwitch1" name="featured">
                        <label class="custom-control-label" for="customSwitch1">Destacado</label>
                    </div>
                </div>
                <div class="col-md-6 d-flex align-items-center justify-content-center">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="Oferta" name="offer">
                        <label class="custom-control-label" for="Oferta">Oferta</label>
                    </div>
                </div>
            </div>
            <div class="col-md-12 my-4 text-right">
                <button type="submit"  class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        /*$(document).ready(function() {
            $('.select2').select2();
        });*/

        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/products/create.blade.php ENDPATH**/ ?>