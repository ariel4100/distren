<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <?php echo $__env->make('page.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <?php echo $__env->make('page.partials.botonera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-6">
                        <!--Carousel Wrapper-->
                        <div class="img position-relative">
                            <img class="position-absolute img-fluid " style="z-index: 11; left: -8px; top: -8px;" src="http://osolelaravel.com/partscam/images/general/ofertas.fw.png" alt="">
                        </div>
                        <?php if($producto->image): ?>
                        <div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">
                            <!--Indicators-->
                            <ol class="carousel-indicators">
                                <?php $__empty_1 = true; $__currentLoopData = $producto->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li data-target="#carousel-example-1z" style="background-color: darkgray;" data-slide-to="<?php echo e($k); ?>" class="<?php echo e($k==0 ? 'active' : ''); ?>" ></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </ol>
                            <!--/.Indicators-->
                            <!--Slides-->
                            <div class="carousel-inner" role="listbox">
                                
                                    
                                        
                                             
                                    
                                
                                <?php $__empty_1 = true; $__currentLoopData = $producto->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    
                                    <div class="carousel-item  <?php echo e($k == 0 ? 'active' : ''); ?>">
                                        <img class="img-fluid" style="height: 297px" src="<?php echo e(asset($item['image'])); ?>"
                                             alt="First slide">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </div>
                            <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                        <!--/.Carousel Wrapper-->
                        <?php else: ?>
                            <img src="<?php echo e(asset('uploads/no-img.png')); ?>" alt="" class="img-fluid">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <h4 class="distren-color font-weight-bold"><?php echo $producto->title; ?></h4>
                        <?php echo $producto->text; ?>

                        <a href="" class="btn distren-fondo shadow-none m-0 px-4 py-2 p-0">Consultar</a>
                    </div>
                </div>
                <?php if(count($producto->closure) > 0): ?>
                <h4 class="distren-color mt-5">Cierres Posibles</h4>
                <div class="row">
                    
                    <?php $__empty_1 = true; $__currentLoopData = $producto->closure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cierre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-2 mb-4">
                            <?php if($cierre->image): ?>
                                <img src="<?php echo e(asset($cierre->image)); ?>" alt="" class="img-fluid" style="height: 100px;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/no-img.png')); ?>" alt="" class="img-fluid">
                            <?php endif; ?>
                            <p class="text-center"><?php echo e($cierre->title); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if(count($producto->termination) > 0): ?>
                <h4 class="distren-color mt-5">Terminaciones</h4>
                <div class="row">
                    
                    <?php $__empty_1 = true; $__currentLoopData = $producto->termination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terminacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-2 mb-4">
                            <?php if($terminacion->image): ?>
                                <img src="<?php echo e(asset($terminacion->image)); ?>" alt="" class="img-fluid" style="height: 100px;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/no-img.png')); ?>" alt="" class="img-fluid">
                            <?php endif; ?>
                            <p class="text-center"><?php echo e($terminacion->title); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </div>
                <?php endif; ?>
                

                <product-carrito :capacidad="<?php echo e(json_encode($producto->capacity)); ?>" :cierres="<?php echo e(json_encode($producto->closure)); ?>" :terminaciones="<?php echo e(json_encode($producto->termination)); ?>" nombreproducto="<?php echo e($producto->title); ?>" nombrecategoria="<?php echo e($producto->category->title); ?>"></product-carrito>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/productos/producto.blade.php ENDPATH**/ ?>