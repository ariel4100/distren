<?php $__env->startPush('style'); ?>
    <style>
        #myClassicTab .nav-link{
            color: #000 !important;
        }
        #myClassicTab li .active{
            border-bottom: 2px solid #FFB900 !important;
        }
        #myClassicTab li a{
            border-bottom: 2px solid transparent;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 8rem">
        <div class="row">
            <div class="col-md-12">
                <h2 class="py-2" style="border-bottom: 2px solid #8BBF40; width: 100px">Buscador</h2>
            </div>
        </div>
        <form class="row justify-content-center my-4" action="<?php echo e(route('buscador')); ?>" method="get">
            <div class="col-md-6">
                <input type="text" name="name" class="form-control my-2" placeholder="Buscar...">
            </div>
            <div class="col-md-6">
                <button type="submit" class="btn distren-fondo btn-md px-5 m-0 my-2">Buscar</button>
            </div>
        </form>


        <div class="row my-5">
            <?php $__empty_1 = true; $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <div class="col-md-3 col-sm-6  mb-5">
                    <a href="<?php echo e(route('producto',['producto' => $item->id])); ?>" class=" " style="text-decoration: none; color: unset;">
                        <div class="text-center">
                            
                            <?php if($item->image): ?>
                                <img src="<?php echo e(asset($item->image[0]['image'])); ?>" style="height: 200px" class="img-fluid " alt="smaple image">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/no-img.png')); ?>" style="height: 200px" alt="" class="img-fluid">
                            <?php endif; ?>
                            
                            <h4 class="text-center py-1 m-0"><?php echo $item->title; ?> </h4>
                            <h5 class="text-center">Desde <del>$<?php echo e($item->capacity->min('price') ?? ''); ?> </del> <span class="distren-color"> $<?php echo e($item->capacity->min('price_offer')); ?></span></h5>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <h4>No se encontraron resultados</h4>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/buscador.blade.php ENDPATH**/ ?>