@extends('page.layouts.app')

@section('content')
    <div class="container mt-5">
        <h2 class="text-uppercase distren-color distren-bold">Compra Online</h2>
    </div>

    <confirmar-component></confirmar-component>
@endsection
