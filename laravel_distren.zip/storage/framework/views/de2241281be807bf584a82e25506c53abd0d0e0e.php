<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('cierres.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('cierres.update',$cierre->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="md-form">
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo $cierre->title; ?>">
                        <label for="title" class="">Titulo</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="md-form">
                        <input type="text" id="order" name="order" class="form-control" value="<?php echo $cierre->order; ?>">
                        <label for="order" class="">Orden</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="number" id="price" name="price" class="form-control" value="<?php echo $cierre->price; ?>">
                        <label for="price" class="">Precio</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="number" id="quantity" name="quantity" class="form-control" value="<?php echo $cierre->quantity; ?>">
                        <label for="quantity" class="">Cantidad</label>
                    </div>
                </div>
            </div>
            
                
                    
                        
                        
                    
                
            
            <div class="row">
                <div class="col-md-12">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                        <label class="custom-file-label" for="customFileLang">Seleccionar Imagen Principal</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 my-5 text-center">
                    <img src="<?php echo e(asset($cierre->image)); ?>" alt="" class="img-fluid" style="height: 200px">
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 my-4 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/closures/edit.blade.php ENDPATH**/ ?>