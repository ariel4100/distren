<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('page.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($empresa): ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-uppercase distren-color distren-bold"><?php echo $empresa->title; ?></h2>
                <?php echo $empresa->text; ?>

            </div>
        </div>
    </div>
    <div class="container my-4">
        <div class="row">
            <div class="col-md-6">
                <h2 class="text-uppercase distren-color distren-bold"><?php echo $empresa->valores; ?></h2>
                <?php echo $empresa->text_valores; ?>

            </div>
            <div class="col-md-6">
                <div class="">
                    <h2 class="text-uppercase distren-color distren-bold"><?php echo $empresa->mision; ?></h2>
                    <?php echo $empresa->text_mision; ?>

                    <h2 class="text-uppercase distren-color distren-bold pt-3"><?php echo $empresa->vision; ?></h2>
                    <?php echo $empresa->text_vision; ?>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/empresa.blade.php ENDPATH**/ ?>