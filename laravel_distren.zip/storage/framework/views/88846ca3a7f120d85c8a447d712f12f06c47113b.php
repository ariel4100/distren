<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #8BBF41;">

    <!-- Navbar brand -->
    <a class="text-white " href="#">Bienvenido/a <?php echo e(ucwords(Auth::user()->username)); ?></a>

    <!-- Collapse button -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
            aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Collapsible content -->
    <div class="collapse navbar-collapse" id="basicExampleNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link text-white" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                    Cerrar Sesion
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
    <!-- Collapsible content -->

</nav>
<!--/.Navbar--><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/partials/header.blade.php ENDPATH**/ ?>