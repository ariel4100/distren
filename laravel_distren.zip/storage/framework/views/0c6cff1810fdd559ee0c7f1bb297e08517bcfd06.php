<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h3 class="distren-color text-uppercase font-weight-bold">Ofertas</h3>
        <div class="row">
            <div class="col-md-12 my-5">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-3">
                            <a href="<?php echo e(route('producto',$item->id)); ?>" class="position-relative" style="color: #9FA3A5;">
                                <div class="view overlay">
                                    <div class="img position-relative">
                                        <img class="position-absolute img-fluid " style="z-index: 1; left: -8px; top: -8px;" src="http://osolelaravel.com/partscam/images/general/ofertas.fw.png" alt="">
                                    </div>
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid " alt="smaple image"  >
                                    <div class="mask flex-center rgba-black-strong">
                                        <span class="text-white">+</span>
                                    </div>
                                </div>
                                <h4 class="text-center py-1 m-0"><?php echo $item->title; ?> </h4>
                                <h5 class="text-center">Desde <del>$<?php echo e($item->price->min('price')); ?> </del> <span class="distren-color"> $<?php echo e($item->price->min('offer_price')); ?></span></h5>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4>No hay registros</h4>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/ofertas.blade.php ENDPATH**/ ?>