<nav>
    <ol class="list-unstyled d-flex">
        <li class="ml-2">Productos</li>
        <li class="ml-2">| <?php echo e(isset($categoria) ? ucwords(strtolower($categoria->title)) : null); ?></li>
        <li class="ml-2">| <?php echo e(isset($producto) ? ucwords(strtolower($producto->title)) : null); ?></li>
    </ol>
</nav><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/partials/breadcrumb.blade.php ENDPATH**/ ?>