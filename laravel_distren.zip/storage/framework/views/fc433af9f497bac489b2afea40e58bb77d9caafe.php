<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-uppercase distren-color distren-bold">Carrito</h2>
    </div>
    <?php ($data = \App\Content::seccionTipo('carrito', 'texto')->first()); ?>
    <?php ($info = json_decode($data->text)); ?>

    <carrito-component :info="<?php echo e(json_encode($info)); ?>"></carrito-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/carrito.blade.php ENDPATH**/ ?>