<?php $__env->startSection('style'); ?>
    <style>
        .nav-link{
            color: #737384;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <?php echo $__env->make('page.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            
            <?php echo $__env->make('page.partials.botonera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-9">
                <div class="row justify-content-center my-3">
                    <div class="col-md-3">
                        <a href="" class="nav-link text-uppercase">
                            Todos
                        </a>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(route('subcategoria',$item->id)); ?>" class="nav-link text-uppercase">
                            <?php echo e($item->title); ?>

                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $categoria->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($item->offer): ?>
                            <div class="col-md-3 text-center">
                                <a href="<?php echo e(route('producto',$item->id)); ?>" class="position-relative" style="color: #9FA3A5;">
                                    <div class="view overlay">
                                        <div class="img position-relative">
                                            <img class="position-absolute img-fluid " style="z-index: 1; left: -8px; top: -8px;" src="http://osolelaravel.com/partscam/images/general/ofertas.fw.png" alt="">
                                        </div>
                                        <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid " alt="smaple image"  >
                                        <div class="mask flex-center rgba-black-strong">
                                            <span class="text-white">+</span>
                                        </div>
                                    </div>
                                    <h4 class="text-center py-1 m-0"><?php echo $item->title; ?> </h4>
                                    <h5 class="text-center">Desde <del>$<?php echo e($item->price->min('price')); ?> </del> <span class="distren-color"> $<?php echo e($item->price->min('offer_price')); ?></span></h5>
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('producto',$item->id)); ?>" class="" style="color: #9FA3A5;">
                                    <div class="view overlay">
                                        <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid " alt="smaple image">
                                        <div class="mask flex-center rgba-black-strong">
                                            <span class="text-white">+</span>
                                        </div>
                                    </div>
                                    <h4 class="text-center py-1 m-0"><?php echo $item->title; ?> </h4>
                                    <h5 class="text-center">Desde <span class="distren-color">$<?php echo e($item->price->min('price')); ?></span></h5>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4>No hay registros</h4>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/productos/categoria.blade.php ENDPATH**/ ?>