<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a href="<?php echo e(route('contenido.create',['seccion' => $section, 'tipo' => $type])); ?>" class="btn btn-primary rounded-pill"><i class="fas fa-plus-circle mx-1"></i>Añadir</a>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">Imagen</th>
                <th scope="col">Texto</th>
                <th scope="col">Orden</th>
                <th scope="col">Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th style="width: 150px"><img src="<?php echo asset($c->image); ?>" class="img-fluid" alt=""></th>
                <td><?php echo str_limit($c->text,150); ?></td>
                <td><?php echo $c->order; ?></td>
                <td>
                    <a class="btn btn-sm btn-warning" href="<?php echo e(route('contenido.edit', [$section, $c->id])); ?>"><i class="fas fa-pen"></i></a>
                    <a class="btn btn-sm btn-danger" onclick="return confirm('¿Realmente desea eliminar este registro?')" href="<?php echo e(route('contenido.delete', [$section, $c->id])); ?>"><i class="fas fa-trash-alt"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2">No hay registros</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('text');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/content/lista.blade.php ENDPATH**/ ?>