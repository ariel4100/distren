<?php $__env->startSection('content'); ?>

    <div class="container p-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Atención</h5>
                <p class="card-text">Para hacer la carga de productos mediante un archivo Excel, deberá cumplir lo siguiente:</p>
                <ol>
                    <li>El archivo debe guardarlo en formato xls</li>
                    <li>No tener CABECERA en la tabla</li>










                </ol>
                <p class="card-text">En el caso de no poseer algún campo, dejar vacío la celda.</p>

                <hr>
                <form onsubmit="carga()" action="<?php echo e(route('productos.carga')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">
                        <div class="col-12 col-md-6">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupFileAddon01">Carga</span>
                                </div>
                                <div class="custom-file">
                                    <input name="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                                    <label class="custom-file-label" data-browser="Buscar" for="inputGroupFile01">Seleccione archivo</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success d-block mx-auto text-uppercase">cargar</button>
                        </div>
                    </div>
                </form>
            </div>






        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/carrito/carga.blade.php ENDPATH**/ ?>