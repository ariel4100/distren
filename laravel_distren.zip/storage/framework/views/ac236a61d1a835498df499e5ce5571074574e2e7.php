<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('capacidades.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('capacidades.update',$capacidad->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="md-form">
                        <input type="text" id="cc" name="cc" class="form-control" value="<?php echo $capacidad->cc; ?>">
                        <label for="cc" class="">CC</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="md-form">
                        <input type="text" id="order" name="order" class="form-control" value="<?php echo $capacidad->order; ?>">
                        <label for="order" class="">Orden</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 my-4 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
        

        
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/capacities/edit.blade.php ENDPATH**/ ?>