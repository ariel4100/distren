<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php ($logos = \App\Content::seccionTipo('logos','texto')->first()); ?>
    <?php ($data = json_decode($logos->text)); ?>
    <title>ADM::Distren</title>
    <link rel="icon" href="<?php echo e(asset(isset($data->image) ? asset($data->image) : null)); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.6/css/mdb.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700" rel="stylesheet">
    <!--<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />--->
    <script>
        document.__API_URL = '<?php echo e(url('/')); ?>';
    </script>
    <!-- CSS ADM SIDEBAR -->
    <style>
        i.material-icons{
            margin-right: .5rem;
            margin-left: .5rem;
            color: #8BBF41;
        }
        i.fa-chevron-right{
            color: #8BBF41;
        }
        #sidebar {
            min-width: 300px;
            max-width: 300px;
            background: #ffffff;
            color: #333333;
            transition: all 0.3s;
            box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
            z-index: 1;
        }

        #sidebar ul li > a {
            color: black;
        }
        #sidebar ul li a {
            display: block;
            color: black;
            padding: 10px;
        }
        #sidebar ul li a:hover, #sidebar ul ul .active {
            background: darkgray;
        }

        #content{
            transition: all 0.3s;
            margin-left: 300px;
        }
        .container{
            width: 90%;
        }

        .distren-color{
            color: #8BBF40 !important;
        }
        .distren-fondo{
            background-color: #8BBF40 !important;
            color: white !important;
        }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body style="font-family: 'Montserrat Light'; ">
<div id="app">
    <!-- Sidebar -->
    <?php echo $__env->make('adm.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="" id="content">
        <!-- Navbar -->
        <?php echo $__env->make('adm.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <?php if(session('status')): ?>
                <div class="alert alert-success my-4" role="alert">
                    <?php echo session('status'); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger  my-4" role="alert">
                    <span class="card-title">Se encontraron los siguientes errores:</span>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<!-- Optional JavaScript -->
<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.6/js/mdb.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>--->
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>


<?php echo $__env->yieldContent('script'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/layouts/app.blade.php ENDPATH**/ ?>