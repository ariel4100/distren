<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('galeria.index',$producto->id)); ?>"><< Volver</a>
        <form class="row" method="POST" action="<?php echo e(route('galeria.update',$galery->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="product_id" name="product_id" value="<?php echo $producto->id; ?>" class="form-control">
            <div class="col-md-12">
                <div class="md-form">
                    <input type="text" id="order" name="order" class="form-control" value="<?php echo $galery->order; ?>">
                    <label for="order" class="">Orden</label>
                </div>
            </div>

            <div class="col-md-12">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                    <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                </div>
            </div>
            <div class="col-md-12 my-5 text-center">
                <img src="<?php echo e(asset($galery->image)); ?>" alt="" class="img-fluid" style="height: 200px">
            </div>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/products/galery/edit.blade.php ENDPATH**/ ?>