<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('productos.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('productos.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="md-form">
                            <input type="text" id="title" name="title" class="form-control">
                            <label for="title" class="">Titulo</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="md-form">
                            <input type="text" id="order" name="order" class="form-control">
                            <label for="order" class="">Orden</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form">
                            <h6>Texto</h6>
                            <textarea id="subtitle" class="md-textarea form-control" name="text" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                            <label class="custom-file-label" for="customFileLang">Seleccionar Imagen Principal</label>
                        </div>
                    </div>
                    <div class="col-md-3 d-flex align-items-center justify-content-center">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="customSwitch1" name="featured">
                            <label class="custom-control-label" for="customSwitch1">Destacado</label>
                        </div>
                    </div>
                    <div class="col-md-3 d-flex align-items-center justify-content-center">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="Oferta" name="offer">
                            <label class="custom-control-label" for="Oferta">Oferta</label>
                        </div>
                    </div>
                </div>
            <div class="row">
                <div class="col-md-6 mt-4">
                    <p>Seleccionar Categoria</p>
                    <select class="custom-select form-control select2" name="category_id">
                        <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo $item->id; ?>"><?php echo $item->title; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="" selected disabled>No hay registros</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-6 mt-4">
                    <p>Seleccionar Subcategoria</p>
                    <select class="custom-select form-control select2" name="subcategory_id">
                        <?php $__empty_1 = true; $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo $item->id; ?>"><?php echo $item->title; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="" selected disabled>No hay registros</option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <capacidad-component :terminaciones="<?php echo e(json_encode($terminaciones)); ?>" :capacidades="<?php echo e(json_encode($capacidades)); ?>" :cierres="<?php echo e(json_encode($cierres)); ?>"></capacidad-component>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        /*$(document).ready(function() {
            $('.select2').select2();
        });*/

        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/adm/products/create.blade.php ENDPATH**/ ?>