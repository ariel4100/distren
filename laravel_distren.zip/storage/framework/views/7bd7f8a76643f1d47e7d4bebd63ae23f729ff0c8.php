<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-uppercase distren-color distren-bold">Compra Online</h2>
    </div>

    <confirmar-component></confirmar-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/confirmar.blade.php ENDPATH**/ ?>