<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 my-4">
                <a href="<?php echo e(route('categoria',$item->id)); ?>" class="" style="color: #9FA3A5;">
                    <div class="view overlay d-flex justify-content-center">
                        <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" style="height: 300px;" alt="smaple image">
                        <div class="mask flex-center rgba-black-strong">
                            <span class="text-white">+</span>
                        </div>
                    </div>
                    <h4 class="text-center py-2 m-0"><?php echo $item->title; ?> </h4>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\distren\resources\views/page/productos/categorias.blade.php ENDPATH**/ ?>